import streamlit as st
import json
import matplotlib.pyplot as plt
import pandas as pd
import plotly.express as px
import numpy as np

# Streamlit app
st.title('Different Companies Data')

# Load the initial DataFrame
with open('C:\\Users\\ACER\\Documents\\dataset1\\filtered_output.json', 'r') as f:
    data = json.load(f)

df = pd.DataFrame(data)

# Sidebar for industry selection
st.sidebar.title('Select Industry')
all_industries = df['industries'].explode().unique()
selected_industry = st.sidebar.selectbox('Select an industry type', [''] + list(all_industries))

# Sidebar for revenue category selection
st.sidebar.title('Select Revenue Category')
selected_revenue_category = st.sidebar.radio('Select revenue category', ['All Companies','Less than $100,000,000', 'More than $100,000,000'], index=None)

# Sidebar for company status selection
st.sidebar.title('Select Company Status')
selected_status = st.sidebar.radio('Select company status', ['All Companies', 'Public Companies', 'Acquired Companies'], index=None)

# Convert the 'Revenue' column to numeric
df['revenue'] = pd.to_numeric(df['revenue'], errors='coerce')

# Filter DataFrame based on selected industry type and revenue category
if selected_industry:
    filtered_df = df[df['industries'].apply(lambda x: selected_industry in x)]
    st.write('Companies in the', selected_industry, 'Industry:')
else:
    filtered_df = df

if selected_revenue_category:
    if selected_revenue_category == 'Less than $100,000,000':
       filtered_df = filtered_df[filtered_df['revenue'] < 100000000]
       st.write('Companies with', selected_revenue_category, 'revenue:')
    elif selected_revenue_category == 'More than $100,000,000':
       filtered_df = filtered_df[filtered_df['revenue'] >= 100000000]
       st.write('Companies with', selected_revenue_category, 'revenue:')
    else:
        st.write('All Companies:')
if selected_status:
    if selected_status == 'Public Companies':
        filtered_df = filtered_df[filtered_df['is_public'] == True]
    elif selected_status == 'Acquired Companies':
        filtered_df = filtered_df[filtered_df['isAcquired'] == True]

# Display the filtered DataFrame
st.dataframe(filtered_df)

# Create a sunburst chart
sunburst_df = filtered_df.head(100)
fig = px.sunburst(sunburst_df, path=['id','ceo','name','type'],
                  values='nbEmployeesMax',
                                color_continuous_scale='RdBu_r',
                                width=800, height=800,
                                template='seaborn',
                                labels={'EmployeesMax': 'Maximum Employees'})
                                


# Display the sunburst chart
st.plotly_chart(fig)





